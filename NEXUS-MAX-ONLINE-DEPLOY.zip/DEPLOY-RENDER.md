# NEXUS MAX ONLINE — deploy em Render

1. Crie um repositório no GitHub chamado `nexus-max-online`.
2. Envie TODOS os arquivos desta pasta para o repositório.
3. No Render, escolha **New → Web Service** e conecte esse repositório.
4. O Render pode usar o `render.yaml`/ou configure:
   - Build: `npm install`
   - Start: `npm start`
5. Em Environment, adicione suas chaves:
   - `OPENAI_API_KEY`
   - `ANTHROPIC_API_KEY`
   - `GEMINI_API_KEY`
   - `XAI_API_KEY`
   - e os respectivos `*_MODEL` se quiser definir modelos.
6. Faça Deploy.
7. O Render fornecerá uma URL `https://...onrender.com`.
8. Abra essa URL no Chrome do Android.
9. Menu ⋮ → **Adicionar à tela inicial** / **Instalar app**.

IMPORTANTE:
- Não coloque as chaves no HTML, JavaScript ou APK.
- As chaves ficam no servidor.
- O serviço foi ajustado para escutar em `0.0.0.0` e na porta `PORT`, como o Render exige.
